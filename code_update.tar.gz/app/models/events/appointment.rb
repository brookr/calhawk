class Appointment < Event
  
  
end