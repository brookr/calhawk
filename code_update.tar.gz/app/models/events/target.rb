class Target < Event
  
  
end