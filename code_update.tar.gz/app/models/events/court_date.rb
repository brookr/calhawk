class CourtDate < Event
  
  
end