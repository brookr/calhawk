class DayMarker < Event
end