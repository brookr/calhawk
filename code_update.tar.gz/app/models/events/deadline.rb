class Deadline < Event
  
  
end