Factory.define :calendar do |cal|
  cal.cal_id  1
  cal.name    'CaseCal'
  #cal.type    'case'
  cal.link_id 3171
  cal.color   '338001'
end
